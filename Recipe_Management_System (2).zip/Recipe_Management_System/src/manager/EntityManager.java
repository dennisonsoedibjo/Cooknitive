package manager;

import java.util.ArrayList;
import java.util.List;

public abstract class EntityManager<T> {
    protected List<T> items;
    
    public EntityManager() {
        this.items = new ArrayList<>();
    }
    
    // Common operations that all entity managers should implement
    public abstract boolean add(T item);
    protected abstract String getItemName(T item);
    
    // Common implementations that can be used by all entity managers
    public List<T> getAllItems() {
        return new ArrayList<>(items);
    }
    
    protected String truncate(String str, int length) {
        if (str == null) return "";
        return str.length() > length ? str.substring(0, length-3) + "..." : str;
    }

    public T getByName(String name) {
        for (T item : items) {
            if (getItemName(item).equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null;
    }

    public boolean delete(String name) {
        for (int i = 0; i < items.size(); i++) {
            if (getItemName(items.get(i)).equalsIgnoreCase(name)) {
                items.remove(i);
                return true;
            }
        }
        return false;
    }
}