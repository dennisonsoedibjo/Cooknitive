package enums;

public enum RecipeCategory {
    BREAKFAST, LUNCH, DINNER, APPETIZER, DESSERT, SNACK
}