package enums;

public enum DietaryPreference {
    VEGETARIAN, VEGAN, GLUTEN_FREE, DAIRY_FREE, NUT_FREE, REGULAR
}