package util;

import java.time.LocalDate;
import java.util.*;

import enums.UnitMeasure;
import manager.RecipeManager;
import model.Ingredient;
import model.Recipe;
import model.ShoppingList;
import program.MenuUI;
import manager.ShoppingListManager;

public class ShoppingListGenerator {
    private final ShoppingListManager manager;
    private final InputValidator validator;

    public ShoppingListGenerator(ShoppingListManager manager) {
        this.manager = manager;
        this.validator = new InputValidator();
    }

    public void manageShoppingList(Scanner scanner, RecipeManager recipeManager) {
        LocalDate date = validator.getDateFromUser(scanner);
        if (date == null) {
            return;
        }

        if (manager.hasListsForDate(date)) {
            System.out.println("\nWarning: Shopping lists already exist for this date.");
            if (!validator.confirmAction(scanner, "Would you like to continue and create another list?")) {
                return;
            }
        }

        String listName = getListNameFromUser(scanner);
        if (listName == null) {
            return;
        }

        ShoppingList shoppingList = new ShoppingList(date, listName);
        generateList(scanner, recipeManager, shoppingList);

        if (!shoppingList.getItems().isEmpty() && 
            validator.confirmAction(scanner, "\nWould you like to save this shopping list?")) {
            if (!manager.add(shoppingList)) {
                System.out.println("Error: A shopping list with name '" + listName + 
                    "' already exists for date " + date);
            } else {
                System.out.println("Shopping list saved successfully!");
            }
        }
    }

    private String getListNameFromUser(Scanner scanner) {
        System.out.print("Enter name for shopping list or leave empty to cancel: ");
        String name = scanner.nextLine().trim();
        return name.isEmpty() ? null : name;
    }

    private void generateList(Scanner scanner, RecipeManager recipeManager, ShoppingList shoppingList) {
    	MenuUI menuManager = new MenuUI();
    	while (true) {
            menuManager.displayShoppingMenu();
            String choice = scanner.nextLine().trim().toUpperCase();
            
            switch (choice) {
                case "A" -> addRecipesToList(scanner, recipeManager, shoppingList);
                case "B" -> addManualIngredient(scanner, shoppingList);
                case "C" -> modifyIngredient(scanner, shoppingList);
                case "D" -> deleteIngredient(scanner, shoppingList);
                case "E" -> shoppingList.clearItems();
                case "F" -> displayCurrentList(shoppingList);
                case "G" -> {
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addRecipesToList(Scanner scanner, RecipeManager recipeManager, ShoppingList shoppingList) {
        recipeManager.displayAsTable(recipeManager.getAllRecipes());
        System.out.print("\nEnter recipe name or leave empty to cancel: ");
        String recipeName = scanner.nextLine().trim();
        
        if (!recipeName.isEmpty()) {
            Recipe recipe = recipeManager.getByName(recipeName);
            if (recipe == null) {
                System.out.println("Recipe not found.");
                return;
            }

            System.out.print("Enter number of servings: ");
            try {
                double servings = Double.parseDouble(scanner.nextLine().trim());
                for (Ingredient ingredient : recipe.getIngredients()) {
                    double quantity = ingredient.getQuantity() * servings;
                    shoppingList.addItem(ingredient.getName(), quantity, ingredient.getUnitMeasure());
                }
                System.out.println("Recipe ingredients added to shopping list!");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number of servings.");
            }
        }
    }

    private void addManualIngredient(Scanner scanner, ShoppingList shoppingList) {
        System.out.print("\nEnter ingredient name or leave empty to cancel: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            return;
        }

        Ingredient existingItem = shoppingList.getItem(name);
        if (existingItem != null) {
            System.out.printf("Ingredient already exists in the list with %.2f %s%n", 
                existingItem.getQuantity(), existingItem.getUnitMeasure());
            
            if (!validator.confirmAction(scanner, "Would you like to update this ingredient?")) {
                return;
            }

            if (existingItem.getUnitMeasure() != UnitMeasure.UNIT) {
                System.out.println("\nCurrent unit: " + existingItem.getUnitMeasure());
                System.out.println("Available units:");
                UnitMeasure[] units = UnitMeasure.values();
                for (int i = 0; i < units.length; i++) {
                    System.out.println((i + 1) + ". " + units[i]);
                }

                while (true) {
                    int choice = validator.getIntInput(scanner, "Select unit to use (or 0 to cancel): ");
                    if (choice == 0) {
                        return;
                    }
                    if (choice >= 1 && choice <= units.length) {
                        UnitMeasure selectedUnit = units[choice - 1];
                        
                        if (!selectedUnit.isInSameCategory(existingItem.getUnitMeasure()) && 
                            selectedUnit != existingItem.getUnitMeasure()) {
                            System.out.println("Warning: Cannot convert between " + 
                                existingItem.getUnitMeasure() + " and " + selectedUnit);
                            if (!validator.confirmAction(scanner, "Would you like to replace the existing unit?")) {
                                continue;
                            }
                        }
                        
                        double quantity = validator.getDoubleInput(scanner, "Enter quantity: ");
                        shoppingList.updateItem(name, quantity, selectedUnit);
                        System.out.println("Ingredient updated successfully!");
                        return;
                    }
                    System.out.println("Invalid choice. Please try again.");
                }
            }
        }

        double quantity = validator.getDoubleInput(scanner, "Enter quantity: ");
        System.out.println("\nAvailable units:");
        UnitMeasure[] units = UnitMeasure.values();
        for (int i = 0; i < units.length; i++) {
            System.out.println((i + 1) + ". " + units[i]);
        }

        while (true) {
            int choice = validator.getIntInput(scanner, "Select unit (or 0 to cancel): ");
            if (choice == 0) {
                return;
            }
            if (choice >= 1 && choice <= units.length) {
                shoppingList.addItem(name, quantity, units[choice - 1]);
                System.out.println("Ingredient added successfully!");
                return;
            }
            System.out.println("Invalid choice. Please try again.");
        }
    }

    private void modifyIngredient(Scanner scanner, ShoppingList shoppingList) {
        displayCurrentList(shoppingList);
        if (shoppingList.getItems().isEmpty()) {
            return;
        }

        System.out.print("\nEnter ingredient name to modify or leave empty to cancel: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            return;
        }

        Ingredient item = shoppingList.getItem(name);
        if (item == null) {
            System.out.println("Ingredient not found in the list.");
            return;
        }

        double quantity = validator.getDoubleInput(scanner, "Enter new quantity: ");
        System.out.println("Available units:");
        UnitMeasure[] units = UnitMeasure.values();
        for (int i = 0; i < units.length; i++) {
            System.out.println((i + 1) + ") " + units[i]);
        }

        while (true) {
            int choice = validator.getIntInput(scanner, "Select new unit (or 0 to keep current): ");
            if (choice == 0) {
                shoppingList.updateItem(name, quantity, item.getUnitMeasure());
                System.out.println("Quantity updated successfully!");
                return;
            }
            if (choice >= 1 && choice <= units.length) {
                UnitMeasure selectedUnit = units[choice - 1];
                
                if (!selectedUnit.isInSameCategory(item.getUnitMeasure()) && 
                    selectedUnit != item.getUnitMeasure()) {
                    System.out.println("Warning: Cannot convert between " + 
                        item.getUnitMeasure() + " and " + selectedUnit);
                    if (!validator.confirmAction(scanner, "Would you like to continue with the new unit?")) {
                        continue;
                    }
                } else if (selectedUnit != item.getUnitMeasure()) {
                    // Convert quantity to the new unit
                    double baseQuantity = item.getUnitMeasure().convertToBase(quantity);
                    quantity = selectedUnit.convertFromBase(baseQuantity);
                }
                
                shoppingList.updateItem(name, quantity, selectedUnit);
                System.out.println("Ingredient updated successfully!");
                return;
            }
            System.out.println("Invalid choice. Please try again.");
        }
    }

    private void deleteIngredient(Scanner scanner, ShoppingList shoppingList) {
        displayCurrentList(shoppingList);
        if (shoppingList.getItems().isEmpty()) {
            return;
        }

        System.out.print("\nEnter ingredient name to delete or leave empty to cancel: ");
        String name = scanner.nextLine().trim();
        if (!name.isEmpty()) {
            if (shoppingList.getItem(name) != null) {
                shoppingList.removeItem(name);
                System.out.println("Ingredient deleted successfully!");
            } else {
                System.out.println("Ingredient not found in the list.");
            }
        }
    }

    private void displayCurrentList(ShoppingList shoppingList) {
        List<Ingredient> items = shoppingList.getItemsSorted();
        if (items.isEmpty()) {
            System.out.println("\nShopping list is empty.");
            return;
        }

        System.out.println("\nCurrent Shopping List:");
    	int i = 1;
        for (Ingredient item : items) {
            System.out.println(i++ + ") " + item);
        }
    }
}