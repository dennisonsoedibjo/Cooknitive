package util;

import java.util.Scanner;
import enums.DietaryPreference;
import enums.RecipeCategory;

public class EnumSelector {
    private final InputValidator validator;
    private final Scanner scanner;

    public EnumSelector(InputValidator validator, Scanner scanner) {
        this.validator = validator;
        this.scanner = scanner;
    }

    public <T extends Enum<T>> T select(Class<T> enumClass, String prompt) {
        T[] values = enumClass.getEnumConstants();
        System.out.println("\nAvailable " + enumClass.getSimpleName() + "s:");
        for (int i = 0; i < values.length; i++) {
            System.out.println((i + 1) + ") " + values[i]);
        }
        
        int index = validator.getIntInput(scanner, prompt) - 1;
        if (index >= 0 && index < values.length) {
            return values[index];
        }
        return null;
    }

    public <T extends Enum<T>> T selectWithDefault(Class<T> enumClass, String prompt, T currentValue) {
        System.out.println("\nCurrent " + enumClass.getSimpleName() + ": " + currentValue);
        System.out.println();
        String input = validator.getStringInput(scanner, prompt + " (leave blank to keep current): ");
        if (input.isEmpty()) {
            return currentValue;
        }
        
        try {
            int index = Integer.parseInt(input) - 1;
            T[] values = enumClass.getEnumConstants();
            if (index >= 0 && index < values.length) {
                return values[index];
            }
        } catch (NumberFormatException e) {
            // Invalid input, return current value
        }
        return currentValue;
    }

    public RecipeCategory selectRecipeCategory() {
        return select(RecipeCategory.class, "Select recipe category (number): ");
    }

    public DietaryPreference selectDietaryPreference() {
        return select(DietaryPreference.class, "Select dietary preference (number): ");
    }
} 