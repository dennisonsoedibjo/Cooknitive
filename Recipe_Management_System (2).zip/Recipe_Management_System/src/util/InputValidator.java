package util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import enums.UnitMeasure;

public class InputValidator {
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
    public int getIntInput(Scanner scanner, String request) {
        while (true) {
            try {
                System.out.print(request);
                int value = scanner.nextInt();
                scanner.nextLine();
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }
    
    public double getDoubleInput(Scanner scanner, String request) {
        while (true) {
            try {
                System.out.print(request);
                double value = scanner.nextDouble();
                scanner.nextLine();
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    public String getStringInput(Scanner scanner, String request) {
        System.out.print(request);
        return scanner.nextLine().trim();
    }

    public boolean confirmAction(Scanner scanner, String request) {
        while (true) {
            System.out.print(request + " (y/n): ");
            String response = scanner.nextLine().trim().toLowerCase();
            if (response.equals("y")) return true;
            if (response.equals("n")) return false;
            System.out.println("Invalid input. Please enter 'y' or 'n'.");
        }
    }

    public UnitMeasure getUnitMeasure(Scanner scanner) {
        while (true) {
            System.out.println("Available unit of measure: Gram (g), Kilogram (kg), Liter (l), Milliliter (ml), Unit");
            System.out.print("Choose unit of measure (g/ml/kg/l/unit): ");
            String input = scanner.nextLine().trim().toUpperCase();
            
            UnitMeasure unit = switch (input) {
                case "G" -> UnitMeasure.G;
                case "ML" -> UnitMeasure.ML;
                case "UNIT" -> UnitMeasure.UNIT;
                case "KG" -> UnitMeasure.KG;
                case "L" -> UnitMeasure.L;
                default -> null;
            };
            
            if (unit != null) return unit;
            System.out.println("Invalid unit. Please try again.");
        }
    }
    
    public LocalDate getDateFromUser(Scanner scanner) {
        while (true) {
            System.out.print("\nEnter date for shopping list (YYYY-MM-DD) or leave empty to cancel: ");
            String dateStr = scanner.nextLine().trim();
            
            if (dateStr.isEmpty()) {
                return null;
            }

            try {
                return LocalDate.parse(dateStr, dateFormatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please use YYYY-MM-DD format.");
            }
        }
    }
} 